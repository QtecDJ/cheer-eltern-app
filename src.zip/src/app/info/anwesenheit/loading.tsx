import { LoadingSkeleton } from "@/components/ui/loading";

export default function Loading() {
  return <LoadingSkeleton />;
}
